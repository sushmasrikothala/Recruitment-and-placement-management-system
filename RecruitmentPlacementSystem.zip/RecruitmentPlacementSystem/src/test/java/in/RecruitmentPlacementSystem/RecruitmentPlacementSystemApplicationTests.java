package in.RecruitmentPlacementSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RecruitmentPlacementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
