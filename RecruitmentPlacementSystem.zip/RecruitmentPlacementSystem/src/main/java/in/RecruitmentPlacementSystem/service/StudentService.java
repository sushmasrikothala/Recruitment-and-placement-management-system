package in.RecruitmentPlacementSystem.service;

import java.util.List;

import org.springframework.stereotype.Service;
import in.RecruitmentPlacementSystem.entity.Student;
import in.RecruitmentPlacementSystem.repository.StudentRepository;

@Service
public class StudentService {

    private final StudentRepository repo;

    public StudentService(StudentRepository repo) {
        this.repo = repo;
    }

    // Register a new student
    public Student register(Student student) {
        return repo.save(student);
    }

    // Login method: returns the student if email & password match, else null
    public Student login(String email, String password) {
        // Trim input to avoid spaces
        email = email.trim();
        password = password.trim();

        List<Student> students = repo.findByEmail(email);

        if (students.isEmpty()) {
            System.out.println("No student found with email: " + email);
            return null;
        }

        Student student = students.stream()
                                  .max((s1, s2) -> s1.getId().compareTo(s2.getId()))
                                  .orElse(null);

        if (student != null) {
            System.out.println("Found student: " + student.getEmail() + ", stored password: " + student.getPassword());
            if (student.getPassword().equals(password)) {
                return student;
            } else {
                System.out.println("Password mismatch!");
            }
        }

        return null; // email found but password incorrect
    }
    
    public Student updateStudent(Long id, Student updatedStudent) {
    	Student existingStudent = repo.findById(id)
    	        .orElseThrow(() -> new RuntimeException("Student not found"));

    	existingStudent.setName(updatedStudent.getName());
    	existingStudent.setBranch(updatedStudent.getBranch());
    	existingStudent.setCgpa(updatedStudent.getCgpa());
    	existingStudent.setSkills(updatedStudent.getSkills());

    	return repo.save(existingStudent);

    }



}
