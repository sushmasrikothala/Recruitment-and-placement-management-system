package in.RecruitmentPlacementSystem.service;

import java.util.List;

import org.springframework.stereotype.Service;

import in.RecruitmentPlacementSystem.entity.Company;
import in.RecruitmentPlacementSystem.entity.Job;
import in.RecruitmentPlacementSystem.repository.CompanyRepository;
import in.RecruitmentPlacementSystem.repository.JobRepository;

@Service
public class JobService {

    private final JobRepository jobRepository;
    private final CompanyRepository companyRepository;

    public JobService(JobRepository jobRepository,
                      CompanyRepository companyRepository) {
        this.jobRepository = jobRepository;
        this.companyRepository = companyRepository;
    }

    // ✅ Add job linked to company
    public Job addJob(Job job, Long companyId) {

        Company company = companyRepository.findById(companyId)
            .orElseThrow(() -> new RuntimeException("Company not found"));

        job.setCompany(company);   // ⭐ THIS FIXES company_id = NULL

        return jobRepository.save(job);
    }

    // ✅ Get all jobs
    public List<Job> getAllJobs() {
        return jobRepository.findAll();
    }
}
