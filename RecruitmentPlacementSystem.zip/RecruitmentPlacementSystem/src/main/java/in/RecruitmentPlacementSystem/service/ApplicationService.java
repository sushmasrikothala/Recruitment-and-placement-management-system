package in.RecruitmentPlacementSystem.service;

import java.util.List;

import org.springframework.stereotype.Service;

import in.RecruitmentPlacementSystem.entity.Application;
import in.RecruitmentPlacementSystem.repository.ApplicationRepository;

@Service
public class ApplicationService {

    private final ApplicationRepository repo;

    public ApplicationService(ApplicationRepository repo) {
        this.repo = repo;
    }

    // ✅ Student applies for a job
    public Application apply(Application application) {
        application.setStatus("Applied"); // default status
        return repo.save(application);
    }

    // ✅ Admin: get all applications
    public List<Application> getAllApplications(){
        return repo.findAll();
    }

    // 🔹 ADD THIS 🔹
    // Student → My Applications
    public List<Application> getByStudent(Long studentId) {
        return repo.findByStudentId(studentId);
    }

    // 🔹 ADD THIS 🔹
    // Company → View applicants for a job
    public List<Application> getByJob(Long jobId) {
        return repo.findByJobId(jobId);
    }

    // 🔹 ADD THIS 🔹
    // Company → Update application status
    public Application updateStatus(Long appId, String status) {
        Application app = repo.findById(appId)
                .orElseThrow(() -> new RuntimeException("Application not found"));

        app.setStatus(status);
        return repo.save(app);
    }
}
