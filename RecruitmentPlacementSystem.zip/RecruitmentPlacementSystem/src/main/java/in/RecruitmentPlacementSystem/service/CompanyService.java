package in.RecruitmentPlacementSystem.service;

import org.springframework.stereotype.Service;
import in.RecruitmentPlacementSystem.entity.Company;
import in.RecruitmentPlacementSystem.repository.CompanyRepository;

@Service
public class CompanyService {

    private final CompanyRepository repo;

    public CompanyService(CompanyRepository repo) {
        this.repo = repo;
    }

    public Company register(Company company) {
        return repo.save(company);
    }

    public Company login(String email, String password) {
        Company company = repo.findByEmail(email);
        if (company != null && company.getPassword().equals(password)) {
            return company;
        }
        return null;
    }
}
