package in.RecruitmentPlacementSystem.service;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import in.RecruitmentPlacementSystem.entity.Resume;
import in.RecruitmentPlacementSystem.entity.Student;
import in.RecruitmentPlacementSystem.repository.ResumeRepository;
import in.RecruitmentPlacementSystem.repository.StudentRepository;

@Service
public class ResumeService {

    private final ResumeRepository resumeRepo;
    private final StudentRepository studentRepo;

    public ResumeService(ResumeRepository resumeRepo, StudentRepository studentRepo) {
        this.resumeRepo = resumeRepo;
        this.studentRepo = studentRepo;
    }

    public Resume uploadResume(Long studentId, MultipartFile file) throws Exception {
        Student student = studentRepo.findById(studentId)
            .orElseThrow(() -> new Exception("Student not found"));

        Resume resume = new Resume();
        resume.setStudent(student);
        resume.setFileName(file.getOriginalFilename());
        resume.setContentType(file.getContentType());
        resume.setData(file.getBytes());

        return resumeRepo.save(resume); // ✅ This actually saves in DB
    }

    public Resume getResume(Long studentId) {
        return resumeRepo.findByStudentId(studentId);
    }
}
