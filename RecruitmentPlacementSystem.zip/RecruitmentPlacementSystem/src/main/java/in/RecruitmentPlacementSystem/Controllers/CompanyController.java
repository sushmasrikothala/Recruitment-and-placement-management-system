package in.RecruitmentPlacementSystem.Controllers;


import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.RecruitmentPlacementSystem.entity.Company;
import in.RecruitmentPlacementSystem.service.CompanyService;

@RestController
@RequestMapping("/company")
@CrossOrigin(origins = "http://localhost:5173")
public class CompanyController {

    private final CompanyService service;

    public CompanyController(CompanyService service) {
        this.service = service;
    }

    // ✅ REGISTER
    @PostMapping("/register")
    public Company register(@RequestBody Company company) {
        return service.register(company);
    }

    // ✅ LOGIN
    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody Company company) {
        Company loggedIn = service.login(company.getEmail(), company.getPassword());

        if (loggedIn == null) {
            return ResponseEntity.status(401).body("Invalid credentials");
        }
        return ResponseEntity.ok(loggedIn);
    }
}
