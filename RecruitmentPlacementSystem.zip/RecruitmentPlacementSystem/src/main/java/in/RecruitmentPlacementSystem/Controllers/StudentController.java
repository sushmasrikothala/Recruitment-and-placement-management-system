
package in.RecruitmentPlacementSystem.Controllers;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import in.RecruitmentPlacementSystem.dto.LoginRequest;
import in.RecruitmentPlacementSystem.entity.Student;
import in.RecruitmentPlacementSystem.service.StudentService;

@RestController
@RequestMapping("/students")
@CrossOrigin(origins = "http://localhost:5173") // VERY IMPORTANT
public class StudentController {

    private final StudentService service;

    public StudentController(StudentService service) {
        this.service = service;
    }

    // ✅ REGISTER
    @PostMapping("/register")
    public ResponseEntity<String> registerStudent(@RequestBody Student student) {
        service.register(student);
        return ResponseEntity.ok("Student registered successfully");
    }

    // ✅ LOGIN
    @PostMapping("/login")
    public ResponseEntity<?> loginStudent(@RequestBody LoginRequest loginRequest) {
        String email = loginRequest.getEmail();
        String password = loginRequest.getPassword();

        System.out.println("LOGIN HIT → " + email);

        Student student = service.login(email, password);

        if (student == null) {
            return ResponseEntity.status(401).body("Invalid credentials");
        }

        return ResponseEntity.ok(student); // RETURN STUDENT JSON
    }
    
    @PutMapping("/update/{id}")
    public ResponseEntity<Student> updateStudentProfile(
            @PathVariable Long id,
            @RequestBody Student updatedStudent
    ) {
        Student student = service.updateStudent(id, updatedStudent);
        return ResponseEntity.ok(student);
    }


}
