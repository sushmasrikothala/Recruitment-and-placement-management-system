package in.RecruitmentPlacementSystem.Controllers;

import java.util.List;

import org.springframework.web.bind.annotation.*;

import in.RecruitmentPlacementSystem.entity.Job;
import in.RecruitmentPlacementSystem.service.JobService;

@RestController
@RequestMapping("/job")
@CrossOrigin(origins = "http://localhost:5173")
public class JobController {

    private final JobService jobService;

    public JobController(JobService jobService) {
        this.jobService = jobService;
    }

    // ✅ Add Job
    @PostMapping("/add/{companyId}")
    public Job addJob(@RequestBody Job job,
                      @PathVariable Long companyId) {

        System.out.println("Company ID received: " + companyId); // DEBUG

        return jobService.addJob(job, companyId);
    }

    // ✅ Get all jobs
    @GetMapping("/all")
    public List<Job> getJobs() {
        return jobService.getAllJobs();
    }
}
