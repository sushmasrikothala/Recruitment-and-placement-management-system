package in.RecruitmentPlacementSystem.Controllers;

import java.util.List;

import org.springframework.web.bind.annotation.*;

import in.RecruitmentPlacementSystem.entity.Application;
import in.RecruitmentPlacementSystem.service.ApplicationService;

@RestController
@RequestMapping("/applications")
@CrossOrigin(origins = "http://localhost:5173")
public class ApplicationController {

    private final ApplicationService service;

    public ApplicationController(ApplicationService service) {
        this.service = service;
    }

    // ✅ Student applies
    @PostMapping("/apply")
    public Application apply(@RequestBody Application application) {
        return service.apply(application);
    }

    // ✅ Admin: all applications
    @GetMapping("/all")
    public List<Application> getAllApplications(){
        return service.getAllApplications();
    }

    // 🔹 ADD THIS 🔹
    // Student → My Applications
    @GetMapping("/student/{studentId}")
    public List<Application> getByStudent(@PathVariable Long studentId) {
        return service.getByStudent(studentId);
    }

    // 🔹 ADD THIS 🔹
    // Company → View applicants job-wise
    @GetMapping("/job/{jobId}")
    public List<Application> getByJob(@PathVariable Long jobId) {
        return service.getByJob(jobId);
    }

    // 🔹 ADD THIS 🔹
    // Company → Update application status
    @PutMapping("/status/{id}")
    public Application updateStatus(
            @PathVariable Long id,
            @RequestParam String status) {
        return service.updateStatus(id, status);
    }
}
