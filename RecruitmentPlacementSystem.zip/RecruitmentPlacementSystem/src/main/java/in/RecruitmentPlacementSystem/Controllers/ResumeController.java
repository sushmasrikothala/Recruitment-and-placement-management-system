package in.RecruitmentPlacementSystem.Controllers;


import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import in.RecruitmentPlacementSystem.entity.Resume;
import in.RecruitmentPlacementSystem.service.ResumeService;

@RestController
@RequestMapping("/resumes")
public class ResumeController {

    private final ResumeService service;

    public ResumeController(ResumeService service) {
        this.service = service;
    }

    @PostMapping("/upload/{studentId}")
    public Resume upload(@PathVariable Long studentId,
                         @RequestParam MultipartFile file) throws Exception {
        return service.uploadResume(studentId, file);
    }

    @GetMapping("/student/{studentId}")
    public Resume getResume(@PathVariable Long studentId) {
        return service.getResume(studentId);
    }
}