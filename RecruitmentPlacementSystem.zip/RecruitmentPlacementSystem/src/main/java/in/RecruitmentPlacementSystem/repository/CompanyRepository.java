package in.RecruitmentPlacementSystem.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import in.RecruitmentPlacementSystem.entity.Company;

public interface CompanyRepository extends JpaRepository<Company, Long> {
    Company findByEmail(String email);
}
