package in.RecruitmentPlacementSystem.repository;

import in.RecruitmentPlacementSystem.entity.Application;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ApplicationRepository extends JpaRepository<Application, Long> {

    // 🔹 Student → My Applications
    List<Application> findByStudentId(Long studentId);

    // 🔹 Company → View Applicants
    List<Application> findByJobId(Long jobId);
}
