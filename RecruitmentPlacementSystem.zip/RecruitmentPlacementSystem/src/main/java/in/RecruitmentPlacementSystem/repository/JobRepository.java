package in.RecruitmentPlacementSystem.repository;

import in.RecruitmentPlacementSystem.entity.Job;


import org.springframework.data.jpa.repository.JpaRepository;

public interface JobRepository extends JpaRepository<Job, Long> {
}