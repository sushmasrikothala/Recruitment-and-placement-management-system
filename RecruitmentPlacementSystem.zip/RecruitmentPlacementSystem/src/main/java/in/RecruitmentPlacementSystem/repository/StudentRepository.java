package in.RecruitmentPlacementSystem.repository;

import in.RecruitmentPlacementSystem.entity.Student;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

public interface StudentRepository extends JpaRepository<Student, Long> {
    List<Student> findByEmail(String email);
}