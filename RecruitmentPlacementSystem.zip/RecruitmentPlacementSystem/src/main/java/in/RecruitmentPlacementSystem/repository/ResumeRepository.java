package in.RecruitmentPlacementSystem.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import in.RecruitmentPlacementSystem.entity.Resume;

public interface ResumeRepository extends JpaRepository<Resume, Long> {
    Resume findByStudentId(Long studentId);
}
