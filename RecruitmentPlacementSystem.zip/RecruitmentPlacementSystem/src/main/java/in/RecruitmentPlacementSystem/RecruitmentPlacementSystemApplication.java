package in.RecruitmentPlacementSystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RecruitmentPlacementSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(RecruitmentPlacementSystemApplication.class, args);
	}

}
